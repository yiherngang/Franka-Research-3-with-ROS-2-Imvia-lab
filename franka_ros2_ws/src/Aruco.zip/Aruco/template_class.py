import cv2
import numpy as np
import os

dirname = os.path.dirname(os.path.realpath(__file__))

'''
YOUR CLASS DOC
'''
class TemplateClass(object):
    def __init__(self):
        return